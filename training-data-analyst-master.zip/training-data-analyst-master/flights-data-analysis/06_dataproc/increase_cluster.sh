gcloud dataproc clusters update ch6cluster\
   --num-preemptible-workers=15 --num-workers=5
