mvn archetype:generate \
  -DarchetypeArtifactId=google-cloud-dataflow-java-archetypes-starter \
  -DarchetypeGroupId=com.google.cloud.dataflow \
  -DgroupId=com.google.cloud.training.flights \
  -DartifactId=chapter4 \
  -Dversion="[1.0.0,2.0.0]" \
  -DinteractiveMode=false \
   
