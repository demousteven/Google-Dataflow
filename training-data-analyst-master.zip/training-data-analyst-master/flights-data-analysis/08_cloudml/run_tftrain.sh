#!/bin/bash
nohup python -u tf_train.py &> train.log  &
