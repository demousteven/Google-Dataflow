/*
 * Copyright (C) 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package com.google.cloud.training.dataanalyst.javahelp;

import java.util.ArrayList;
import java.util.List;
import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;
import com.google.cloud.dataflow.sdk.Pipeline;
import com.google.cloud.dataflow.sdk.io.BigQueryIO;
import com.google.cloud.dataflow.sdk.options.Default;
import com.google.cloud.dataflow.sdk.options.Description;
import com.google.cloud.dataflow.sdk.options.PipelineOptions;
import com.google.cloud.dataflow.sdk.options.PipelineOptionsFactory;
import com.google.cloud.dataflow.sdk.options.Validation;
import com.google.cloud.dataflow.sdk.values.PCollection;

/**
 * find ReverseId and Remove the row where ReverseId and KeyId are Equal 
 * 
 * @author Steven Murhula Kahomboshi 
 *
 */
public class ReverseID {
	
	private static final String OutTransactionsTable =
		      "dev6celbux:dev6celbux.outtransaction";
	

	public static interface MyOptions extends PipelineOptions {
		
		    @Description("BigQuery table to write to, specified as "
		        + "<project_id>:<dataset_id>.<table_id>. The dataset must already exist.")
		    @Default.String(OutTransactionsTable)
		    @Validation.Required
		    String getOutput();
		    void setOutput(String value);
	}

	//@SuppressWarnings("serial")
	public static void main(String[] args) {
		MyOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(MyOptions.class);
		Pipeline p = Pipeline.create(options);

		 PCollection<TableRow> TransactionData = p.apply(
			     BigQueryIO.Read.named("transactioread")
			     .fromQuery("select * from (select [From],__key__.id,DateTime,To,Type,TT,ToType,ReverseID,FromType,Amount,Comms,ToMethod,FromMethod,Metadata,Voucher.id from [dev6celbux:dev6celbux.F1_11] OMIT RECORD IF EVERY( __key__.id == ReverseID and ReverseID is not null and Type = 'reverse') OMIT RECORD IF (ReverseId IS not NULL)"));
		 		
		 List<TableFieldSchema> fields = new ArrayList<>();
		 fields.add(new TableFieldSchema().setName("From").setType("STRING"));
		 fields.add(new TableFieldSchema().setName("__key___id").setType("INTEGER"));
		 fields.add(new TableFieldSchema().setName("DateTime").setType("INTEGER"));
		 fields.add(new TableFieldSchema().setName("To").setType("STRING"));
		 fields.add(new TableFieldSchema().setName("Type").setType("STRING"));
		 fields.add(new TableFieldSchema().setName(" TT").setType("INTEGER"));
		 fields.add(new TableFieldSchema().setName("ToType").setType("STRING"));
		 fields.add(new TableFieldSchema().setName("ReverseID").setType("INTEGER"));
		 fields.add(new TableFieldSchema().setName("FromType").setType("STRING"));
		 fields.add(new TableFieldSchema().setName("Amount").setType("INTEGER"));
		 fields.add(new TableFieldSchema().setName("Comms").setType("INTEGER"));
		 fields.add(new TableFieldSchema().setName("ToMethod").setType("STRING"));
		 fields.add(new TableFieldSchema().setName("FromMethod").setType("STRING"));
		 fields.add(new TableFieldSchema().setName("Metadata").setType("STRING"));
		 fields.add(new TableFieldSchema().setName("Voucher_id").setType("INTEGER"));
		 TableSchema schema = new TableSchema().setFields(fields);
		 TransactionData.apply(BigQueryIO.Write
			     .named("Write")
			     .to("dev6celbux:dev6celbux.outtransaction")
			     .withSchema(schema)
			     .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_TRUNCATE));
		 p.run();
				
				};
				
		
		
	}

