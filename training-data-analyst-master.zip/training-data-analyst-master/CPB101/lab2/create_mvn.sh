mvn archetype:generate \
  -DarchetypeArtifactId=google-cloud-dataflow-java-archetypes-starter \
  -DarchetypeGroupId=com.google.cloud.dataflow \
  -DgroupId=com.google.cloud.training.dataanalyst.javahelp \
  -DartifactId=javahelp \
  -Dversion="[1.0.0,2.0.0]" \
  -DinteractiveMode=false \
