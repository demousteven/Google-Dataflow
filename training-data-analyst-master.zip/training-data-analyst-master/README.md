# training-data-analyst 

Labs and demos for courses in the Data Engineer track of GCP Training (http://cloud.google.com/training).

CPB100: Google Cloud Platform Big Data and Machine Learning Fundamentals
https://cloud.google.com/training/courses/cpb100

CPB101: Serverless Data Analysis with BigQuery and Cloud Dataflow
https://cloud.google.com/training/courses/cpb101

CPB102: Machine Learning with Cloud ML
https://cloud.google.com/training/courses/cpb102
