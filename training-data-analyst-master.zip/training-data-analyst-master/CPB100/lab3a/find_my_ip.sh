#!/bin/bash

wget -qO - http://ipecho.net/plain; echo
