This is based on the Google Cloud Solution https://github.com/GoogleCloudPlatform/spark-recommendation-engine by Matthieu Mayran.
It has been adapted to fit a training module.
