apt-get install python-dev
apt-get install libssl-dev
pip install earthengine-api
